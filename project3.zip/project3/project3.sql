-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 17, 2024 at 03:47 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project3`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `postid` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `content` varchar(400) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`postid`, `username`, `content`, `email`, `date`) VALUES
(1, 'Hoseinnejad', 'mamnoon', 'aa@gmail.com', '0000-00-00'),
(1, 'حانیه', 'زیبا بود', 'hanie@gmail.com', '0000-00-00'),
(1, 'hany', 'salam.mamnoon', 'hany@gmail.com', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` varchar(20) NOT NULL,
  `city` varchar(30) NOT NULL,
  `content` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `city`, `content`, `title`) VALUES
('1', 'esfahan', 'شهر اصفهان ، مرکز استان اصفهان محسوب می شود و در فرهنگ ایران به «نصف جهان» شهرت دارد. شهری توریستی و باستانی می باشد که در مرکز ایران واقع شده است. این شهر به دلیل وجود بناهای تاریخی به عنوان میراث تاریخی در یونسکو به ثبت رسیده است. در روزگاران قدیم این شهر را با نام های مانند سپاهان، صفاهان، صفویان، پارتاک، یهودیه، گابیان و… نیز می شناختند...', 'اصفهان نصف جهان'),
('2', 'tehran', 'شهر تهران پایتخت سیاسی، اجتماعی و تجاری ایران است. این شهر از زمان سلسله قاجار به عنوان پایتخت سیاسی ایران انتخاب شد. تهران امروزه بیش از ۱۰ میلیون‌نفر جمعیت دارد و دومین شهر پرجمعیت خاورمیانه به حساب می‌آيد. با این‌حال، جاهای دیدنی تهران تنوع بالایی دارند و بهتر است قبل از سفر برنامه سفر خود را مشخص کنید.', 'تهران'),
('3', 'yazd', 'یزد شهر مشهور ایران زمین است و در اقصا نقاط جهان شناخته شده است. از تمام کشورهای دور و نزدیک جهان، گردشگران و جهان‌گردان به پهنۀ وسیع ایران زیبا می‌شتابند و شهر تاریخی و باستانی یزد را به عنوان مقصد سفر خود انتخاب می‌کنند.', 'شهر باستانی یزد'),
('4', 'hormoz', 'جزیره هرمز جزیره ای در نزدیکی تنگه هرمز است که به علت موقعیت جغرافیایی، کلید خلیج فارس نامیده می شود. این جزیره به جزیره سرخ و جزیره خاک های خوراکی ایران هم معروف است، چرا که بخش قابل توجهی از خاک های منطقه به رنگ سرخ هستند و در برخی از نقاط آن گونه ای خاک خوراکی وجود دارد. در ادامه شما را با بهشت زمین شناسی ایران، جزیره هرمز آشنا می کنیم\r\n\r\n', 'جزیره زیبای هرمز'),
('5', 'mashhad', 'شهر مشهد و اقع در استان خراسان رضوی یکی از استان‌های تاریخی و مذهبی ایران محسوب می‌شود. این شهر سالانه میزبان حدود ۲۷ میلیون نفر از مسافران داخلی و خارجی است که برای زیارت و مراسم‌های مذهبی به این مکان سفر می‌کنند. دلیل اصلی این حجم مسافر و گردشگر وجود بارگاه امام رضا(ع) در شهر مشهد است. این شهر به لحاظ فرهنگی هم بسیار غنی است.\r\n\r\n', 'شهر زیارتی مشهد'),
('6', 'gilan', 'گیلان به عنوان یکی از زیباتــرین استان های کشور به لحاظ جاذبه های طبیعی و گردشگری یاد می شود و سالانه میلیون ها نفر گردشگر به گیلان رو می آورند، گیلان سرزمین طلای سبز از دیدگان بسیاری از دوستــداران تاریخ و طبیعت به دور مانده است.', 'گیلان بهشت ایران'),
('7', 'kordestan', 'بدون شک یکی از قطب های مهم گردشگری شمال غرب کشورمان استان سرسبز و زیبای کردستان است. آب و هوای معتدل و مطلوب به خصوص در فصول بهار و تابستان، طبیعت بکر، چشم اندازهای زیبا، فرهنگ غنی و مردمان خونگرم و آثار تاریخی متنوع که در جای جای این خطه یافت می شود، باعث شده است تا سالانه گردشگران داخلی و خارجی بسیاری به این استان سفر کنند.\r\n\r\n', 'کردستان'),
('8', 'shiraz', 'در شیراز شما با جاذبه های گردشگری و متنوعی رو به رو هستید که برترین بناهای تاریخی و باستانی ایران محسوب می شوند. دروازه قرآن، ارگ کریم خان، مجموعه وکیل، مسجد نصیرالملک، مسجد جامع عتیق، تخت جمشید، مقبره کوروش، مجموعه پاسارگاد، نقش رجب، نقش رستم و سایر اماکن، قلعه ها و مکان هایی که به دوران ساسانی مربوط هستند و همگی گویای قدمت شهر شیراز بوده و نشان از تاریخ غنی و فرهنگ قوی آن دارند', 'شیراز');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `email` varchar(50) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`email`, `pass`) VALUES
('hi@gmail.com', '123'),
('hanie@gmail.com', '1234'),
('hany@gmail.com', '1234');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
