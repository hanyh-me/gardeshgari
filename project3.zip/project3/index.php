<!DOCTYPE html>
<html lang="fa" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <title>ورود</title>
    <link rel="stylesheet" href="source/css/login-style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>
  <body>
    <img class="logo" src="source/img/title.png" />
    <div class="wrapper">
      <div class="title-text">
        <div class="title login">ورود</div>
        <div class="title signup">ثبت نام</div>
      </div>
      <div class="form-container">
        <div class="slide-controls">
          <input type="radio" name="slide" id="login" checked />
          <input type="radio" name="slide" id="signup" />
          <label for="login" class="slide login">ورود</label>

          <label for="signup" class="slide signup">ثبت نام</label>

          <div class="slider-tab"></div>
        </div>
        <div class="form-inner">
          <form action=./checking.php method=GET class="login">
              <div class="field">
                <input name="email" placeholder="ایمیل" dir="rtl" required type="email" />
              </div>
              <div class="field">
                <input name="pass" placeholder="رمز عبور" dir="rtl" required type="password"/>
              </div>
              <div class="pass-link" dir="rtl">
                <a href="#">پسورد خود را فراموش کردید؟</a>
              </div>
              <div class="field btn">
                <div class="btn-layer"></div>
                <input type="submit" value="ورود"  />
              </div>
              <div class="signup-link">
                عضو نیستید <a href="">الان ثبت نام کنید</a>
              </div>
          </form>
          <form action=./checking.php method=POST class="signup">
            <div class="field">
              <input name="email" placeholder="ایمیل" required type="email" />
            </div>
            <div class="field">
              <input name="pass" placeholder="رمز عبور" required type="password" />
            </div>
            <div class="field">
              <input name="pass2" placeholder=" تایید کلمه عبور" required type="password" onkeyup="keyUp()" />
            </div>
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" value="ثبت نام" />
            </div>
          </form>
        </div>
      </div>
    </div>

    <script>
      const loginText = document.querySelector(".title-text .login");
      const loginForm = document.querySelector("form.login");
      const loginBtn = document.querySelector("label.login");
      const signupBtn = document.querySelector("label.signup");
      const signupLink = document.querySelector("form .signup-link a");
      signupBtn.onclick = () => {
        loginForm.style.marginLeft = "-50%";
        loginText.style.marginLeft = "-50%";
      };
      loginBtn.onclick = () => {
        loginForm.style.marginLeft = "0%";
        loginText.style.marginLeft = "0%";
      };
      signupLink.onclick = () => {
        signupBtn.click();
        return false;
      };

      function keyUp(event) {
        if(document.getElementsByName('pass')[1].value != document.getElementsByName('pass2')[0].value ){
          console.log("password dosent match");
        }else{

        }
      }
      
    </script>
  </body>
</html>
