
<!DOCTYPE html>
<html lang="fa" dir="rtl">
    <head>
        <link href=source/css/site-style.css rel=stylesheet>
        <title>وب سایت گردشگری</title>
    </head>
    <body>
        <div theme="blog">
            <section class="maincontainer">
                <div class="container is-page">
                    <section class="blog-header">
                        <img src="source/img/final_header.png">
                    </section>
                    <section class=search>
                        <form action=search/search.php method=GET>
                            <button type=submit class=button>جستجو</button>

                            <input dir="rtl" type=text placeholder='نام شهر' name=search>
                        </form>
                    </section>
                    <section class="blog-list">
                        <div class="blog-post">
                        <a href="post/post1.php"><img src="source/img/esfahan.jpg" style="width: 900px;"></a>
                        <h2>اصفهان نصف جهان</h2>
                        <p>شهر اصفهان ، مرکز استان اصفهان محسوب می شود و در فرهنگ ایران به «نصف جهان» شهرت دارد.  شهری توریستی و باستانی می باشد که در مرکز ایران واقع شده است. این شهر به دلیل وجود بناهای تاریخی به عنوان میراث تاریخی در یونسکو به ثبت رسیده است. در روزگاران قدیم این شهر را با نام های مانند سپاهان، صفاهان، صفویان، پارتاک، یهودیه، گابیان و… نیز می شناختند...</p>
                        <a class="button is-small" href="post/post1.php">دیدن پست</a>
                        </div>
                        <div class="blog-post">
                        <a href="/post/post2.php"><img src="source/img/hormoz.jpg" style="width: 900px;"></a>
                        <h2 style="font-weight: bold; text-align: right;">جزیره زیبای هرمز</h2>
                        <p>جزیره هرمز جزیره ای در نزدیکی تنگه هرمز است که به علت موقعیت جغرافیایی، کلید خلیج فارس نامیده می شود. این جزیره به جزیره سرخ و جزیره خاک های خوراکی ایران هم معروف است، چرا که بخش قابل توجهی از خاک های منطقه به رنگ سرخ هستند و در برخی از نقاط آن گونه ای خاک خوراکی وجود دارد. در ادامه شما را با بهشت زمین شناسی ایران، جزیره هرمز آشنا می کنیم</p>
                        <a class="button is-small" href="/post/post2.php">دیدن پست</a>
                        </div>
                        <div class="blog-post">
                        <a href="/post/post3.php"><img src="source/img/mashhad.jpg" style="width: 900px;"></a>
                        <h2>شهر زیارتی مشهد</h2>
                        <p>شهر مشهد و اقع در استان خراسان رضوی یکی از استان‌های تاریخی و مذهبی ایران محسوب می‌شود. این شهر سالانه میزبان حدود ۲۷ میلیون نفر از مسافران داخلی و خارجی است که برای زیارت و مراسم‌های مذهبی به این مکان سفر می‌کنند. دلیل اصلی این حجم مسافر و گردشگر وجود بارگاه امام رضا(ع) در شهر مشهد است. این شهر به لحاظ فرهنگی هم بسیار غنی است.</p>
                        <a class="button is-small" href="/post/post3.php">دیدن پست</a>
                        </div>
                        <div class="blog-post">
                        <a href="/post/post4.php"><img src="source/img/yazd.jpg" style="width: 900px;"></a>
                        <h2>شهر باستانی یزد</h2>
                        <p>یزد شهر مشهور ایران زمین است و در اقصا نقاط جهان شناخته شده است. از تمام کشورهای دور و نزدیک جهان، گردشگران و جهان‌گردان به پهنۀ وسیع ایران زیبا می‌شتابند و شهر تاریخی و باستانی یزد را به عنوان مقصد سفر خود انتخاب می‌کنند. </p>
                        <a class="button is-small" href="/post/post4.php">دیدن پست</a>
                        </div>
                        <div class="blog-post">
                        <a href="/post/post5.php"><img src="source/img/gilan.jpg" style="width: 900px;"></a>
                        <h2>گیلان بهشت ایران</h2>
                        <p>گیلان به عنوان یکی از زیباتــرین استان های کشور به لحاظ جاذبه های طبیعی و گردشگری یاد می شود و سالانه میلیون ها نفر گردشگر به گیلان رو می آورند، گیلان سرزمین طلای سبز از دیدگان بسیاری از دوستــداران تاریخ و طبیعت به دور مانده است.</p>
                        <a class="button is-small" href="/post/post5.php">دیدن پست</a>
                        </div>
                        <div class="blog-post">
                        <a href="/post/post6.php"><img src="source/img/kordestan.jpg" style="width: 900px;"></a>
                        <h2>کردستان</h2>
                        <p> دون شک یکی از قطب های مهم گردشگری شمال غرب کشورمان استان سرسبز و زیبای کردستان است. آب و هوای معتدل و مطلوب به خصوص در فصول بهار و تابستان، طبیعت بکر، چشم اندازهای زیبا، فرهنگ غنی و مردمان خونگرم و آثار تاریخی متنوع که در جای جای این خطه یافت می شود، باعث شده است تا سالانه گردشگران داخلی و خارجی بسیاری به این استان سفر کنند.</p>
                        <a class="button is-small" href="/post/post6.php">دیدن پست</a>
                        </div>
                        <div class="blog-post">
                        <a href="/post/post7.php"><img src="source/img/tehran.jpg" style="width: 900px;"></a>
                        <h2>تهران</h2>
                        <p>شهر تهران پایتخت سیاسی، اجتماعی و تجاری ایران است. این شهر از زمان سلسله قاجار به عنوان پایتخت سیاسی ایران انتخاب شد. تهران امروزه بیش از ۱۰ میلیون‌نفر جمعیت دارد و دومین شهر پرجمعیت خاورمیانه به حساب می‌آيد. با این‌حال، جاهای دیدنی تهران تنوع بالایی دارند و بهتر است قبل از سفر برنامه سفر خود را مشخص کنید.</p>
                        <a class="button is-small" href="/post/post7.php">دیدن پست</a>
                        </div>
                        <div class="blog-post">
                        <a href="/post/postnull.php"><img src="source/img/shiraz.jpg" style="width: 900px;"></a>
                        <h2>شیراز</h2>
                        <p>در شیراز شما با جاذبه های گردشگری و متنوعی رو به رو هستید که برترین بناهای تاریخی و باستانی ایران محسوب می شوند. دروازه قرآن، ارگ کریم خان، مجموعه وکیل، مسجد نصیرالملک، مسجد جامع عتیق، تخت جمشید، مقبره کوروش، مجموعه پاسارگاد، نقش رجب، نقش رستم و سایر اماکن، قلعه ها و مکان هایی که به دوران ساسانی مربوط هستند و همگی گویای قدمت شهر شیراز بوده و نشان از تاریخ غنی و فرهنگ قوی آن دارند</p>
                        <a class="button is-small" href="/post/postnull.php">دیدن پست</a>
                        </div>
                    </section>

                </div>
            </section>
            <div class="footer-wrapper">
            </div>
        </div>
    </body>
</html>
