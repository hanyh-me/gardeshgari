<?php
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
   
        $conn = mysqli_connect('localhost', 'root', '', 'project3');

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "SELECT * FROM users WHERE email='" . $_GET['email'] . "'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          $row = $result->fetch_assoc();
          if ($_GET['pass'] == $row['pass']){
              header("Location: ./home");
          }
          else{
            echo "password incorrect";
          }
        }else{
          echo "email dose not exist";
        }

        $conn->close();

        
        }
        else if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
          $conn = mysqli_connect('localhost', 'root', '', 'project3');
  
          if (!$conn) {
              die("Connection failed: " . mysqli_connect_error());
          }
  
          $sql = "INSERT INTO users (email, pass) VALUES ('" . $_POST['email'] . "', '" . $_POST['pass'] . "')";
          $conn->query($sql);
  
          $conn->close();

          header("Location: ./");

  
          
          }
?>