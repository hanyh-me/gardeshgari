<?php
    if(isset($_GET['search'])) {
            $param = $_GET['search'];

            $conn = mysqli_connect('localhost', 'root', '', 'project3');

            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            $result = $conn->query("SELECT * FROM posts");
    }
    $conn->close();
?>

<!DOCTYPE html>
<html  lang="fa" dir="rtl">
    <head>
        <link href=../source/css/site-style.css rel=stylesheet>
        <title>جستوجو</title>
    </head>
    <body>
        <div theme="blog">
            <section class="maincontainer">
                <div class="container is-page">
                    <header class="navigation-header">
                        <section class="top-links">
                            <a href=../ >Home</a><p>|</p>
                        </section>
                    </header>
                    <section class=blog-header>
                        <?php
                            if(isset($_GET['search'])) {
                                $numOfResult =0;
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        if (strpos($row["title"],$param) !== false) {
                                            $numOfResult++;
                                        }
                                    }
                                    $result->data_seek(0);
                                    echo '<h1>' . $numOfResult . 'نتیجه برای کلمه "' . $param . '" یافت شد</h1>';
                                }
                        
                            }
                        ?>
                    </section>
                    <section class=search>
                        <form action=search.php method=GET>
                            <button type=submit class=button>جستجو</button>
                            <input dir="rtl" type=text placeholder='نام شهر' name=search>
                        </form>
                    </section>
                    
                    <section class="blog-list">
                        <?php
                            if(isset($_GET['search'])) {

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        if (strpos($row["title"],$param) !== false) {
                                            echo '<div class="blog-post">
                                            <a href="../post/post' . $row["id"] . '.php"><img src="../source/img/' . $row["city"] . '.jpg" style="width: 900px;"></a>
                                            <h2>' . $row["title"] . '</h2>
                                            <p>' . $row["content"]. '</p>
                                            <a class="button is-small" href="../post/post' . $row["id"] . '.php">دیدن پست</a>
                                            </div>';
                                        }
                                    }
                                }
                            } 
                        ?>

                        <div class=is-linkback>
                        <br>
        <a href=../ >برگشت به صفحه اصلی</a>
                        </div>
                    </section>
                </div>
            </section>
        </div>
    </body>

</html>
